package com.cg.payroll;

public class ObjectSerializationDemo {

}
