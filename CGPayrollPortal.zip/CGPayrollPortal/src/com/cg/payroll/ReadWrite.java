package com.cg.payroll;

public class ReadWrite {

}
