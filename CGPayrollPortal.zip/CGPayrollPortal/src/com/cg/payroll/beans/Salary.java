package com.cg.payroll.beans;

import javax.persistence.Embeddable;

@Embeddable

public class Salary {
	private int basicSalary, hra ,convenyenceAllowance ;
	private int otherAllowance, personalAllowance ,monthlyTax , epf , companyPf;
	
	
	public Salary() {
		super();
	}


	public Salary(int basicSalary, int epf, int companyPf) {
		super();
		this.basicSalary = basicSalary;
		this.epf = epf;
		this.companyPf = companyPf;
	}


	public int getBasicSalary() {
		return basicSalary;
	}




	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}




	public int getEpf() {
		return epf;
	}




	public void setEpf(int epf) {
		this.epf = epf;
	}




	public int getCompanyPf() {
		return companyPf;
	}




	public void setCompanyPf(int companyPf) {
		this.companyPf = companyPf;
	}




	public Salary(int basicSalary, int hra, int convenyenceAllowance, int otherAllowance, int personalAllowance,
			int monthlyTax, int epf, int companyPf) {
		super();
		this.basicSalary = basicSalary;
		this.hra = hra;
		this.convenyenceAllowance = convenyenceAllowance;
		this.otherAllowance = otherAllowance;
		this.personalAllowance = personalAllowance;
		this.monthlyTax = monthlyTax;
		this.epf = epf;
		this.companyPf = companyPf;
	}




	public int getHra() {
		return hra;
	}




	public void setHra(int hra) {
		this.hra = hra;
	}




	public int getConvenyenceAllowance() {
		return convenyenceAllowance;
	}




	public void setConvenyenceAllowance(int convenyenceAllowance) {
		this.convenyenceAllowance = convenyenceAllowance;
	}




	public int getOtherAllowance() {
		return otherAllowance;
	}




	public void setOtherAllowance(int otherAllowance) {
		this.otherAllowance = otherAllowance;
	}




	public int getPersonalAllowance() {
		return personalAllowance;
	}




	public void setPersonalAllowance(int personalAllowance) {
		this.personalAllowance = personalAllowance;
	}




	public int getMonthlyTax() {
		return monthlyTax;
	}




	public void setMonthlyTax(int monthlyTax) {
		this.monthlyTax = monthlyTax;
	}




	@Override
	public String toString() {
		return "Salary [basicSalary=" + basicSalary + ", hra=" + hra + ", convenyenceAllowance=" + convenyenceAllowance
				+ ", otherAllowance=" + otherAllowance + ", personalAllowance=" + personalAllowance + ", monthlyTax="
				+ monthlyTax + ", epf=" + epf + ", companyPf=" + companyPf + "]";
	}
	
	
	}
	
	
	
		