package com.cg.payroll.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;



@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginServlet() {
        super();
     
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int associateId=Integer.parseInt(request.getParameter("associateID"));
		String password=request.getParameter("password");
		
		Associate associate=new Associate(associateId,password);
		RequestDispatcher dispatcher=null;
		
		
		if (associate.getAssociateID()==1111&&password.equals("aaaa")) {
		dispatcher=request.getRequestDispatcher("loginSucessPage.jsp");
		request.setAttribute("associate", associate);
		dispatcher.forward(request, response);
}
		else {
			dispatcher=request.getRequestDispatcher("loginPage.jsp");
			request.setAttribute( "error" ,"associate id or paassword is wrong");
			dispatcher.forward(request, response);
		}
			
	}
}


