package com.cg.payroll.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	PayrollServices payrollServices=new PayrollServicesImpl();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailId=request.getParameter("emailId");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String pancard=request.getParameter("pancard");
		int yearlyInvestmentUnder80C=Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C"));
		int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
		String bankName=request.getParameter("bankName");
		int accountNumber=Integer.parseInt(request.getParameter("accountNumber"));
		String ifscCode=request.getParameter("ifscCode");
		int epf=Integer.parseInt(request.getParameter("epf"));
		int companyPf=Integer.parseInt(request.getParameter("companyPf"));
		
		/*PrintWriter out =response.getWriter();
		
		out.println("<html><body><div align = 'center' >");
		out.println("first Name:" +firstName+"<br>");
		out.println("last Name:" +lastName+"<br>");
		out.println("emailId:" +emailId+"<br>");
		out.println("department:" +department+"<br>");
		out.println("designation:" +designation+"<br>");
		out.println("pancard:" +pancard+"<br>");
		out.println("yearlyInvestmentUnder80C:" +yearlyInvestmentUnder80C+"<br>");
		out.println("basicSalary:" +basicSalary+"<br>");
		out.println("bankName:" +bankName+"<br>");
		out.println("accountNumber:" +accountNumber+"<br>");
		out.println("ifscCode:" +ifscCode+"<br>");
		out.println("epf:" +epf+"<br>");
		out.println("companyPf:" +companyPf+"<br>");
		
		out.println("</div>");
		out.print("</body></html>");*/
		
	
		
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
		
		int associateID=payrollServices.acceptAssociateDetails(associate);
		
		RequestDispatcher dispatcher=null;
		dispatcher=request.getRequestDispatcher("registrationSucessPage.jsp");
		request.setAttribute("associate", associate);
		dispatcher.forward(request, response);
	

}
}