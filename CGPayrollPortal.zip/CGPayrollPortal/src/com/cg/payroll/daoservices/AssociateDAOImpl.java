package com.cg.payroll.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.payroll.beans.Associate;
public class AssociateDAOImpl  implements AssociateDAO{
	private EntityManagerFactory entityManagerfactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Associate save(Associate associate) {//transient state
		EntityManager entityManager=entityManagerfactory.createEntityManager();//entity manager factory is a interface
		entityManager.getTransaction().begin();
		entityManager.persist(associate);//persistence state it will update to the current data
		entityManager.getTransaction().commit();//detache state no change allowed afer that
		entityManager.clear();
		return associate;
	}
	@Override
	public boolean update(Associate associate) {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.getTransaction().commit();
		entityManager.clear();
		return true;
	}
	@Override
	public Associate findOne(int associateId) {
		return entityManagerfactory.createEntityManager().find(Associate.class, associateId);
		
	}
	@Override
	public List<Associate> findAll() {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
	Query query=	entityManager.createQuery("from Associate a");// used to create multiple objects
		return query.getResultList();
	}

}





