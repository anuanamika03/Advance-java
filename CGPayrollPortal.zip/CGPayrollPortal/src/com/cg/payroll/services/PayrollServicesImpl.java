package com.cg.payroll.services;


import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class PayrollServicesImpl  implements PayrollServices{
	private AssociateDAO associateDAO;
	 
	public PayrollServicesImpl() {
		associateDAO=new AssociateDAOImpl();
			
		}
		 public PayrollServicesImpl(AssociateDAO associateDAO) {
			 super();
			 this.associateDAO=associateDAO;
	}
	
	
	
//  private  AssociateDAO associateDAO= new AssociateDAOImpl();

	
	  public int acceptAssociateDetails(Associate associate) {
			
	
	
		associate=associateDAO.save(associate);
		
		return associate.getAssociateID();
	} 

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=this.getAssociateDetails(associateId);
		int hra=associate.getSalary().getBasicSalary()*40/100;
		int convenyanceallowance=associate.getSalary().getConvenyenceAllowance()*30/100;
		int personalallowance=associate.getSalary().getPersonalAllowance()*20/100;
		int otherallowance=associate.getSalary().getOtherAllowance()*20/100;
		int grossSalary=associate.getSalary().getBasicSalary()+hra+convenyanceallowance+personalallowance+otherallowance+associate.getSalary().getEpf();
		int annualSalary=grossSalary*12;
		int taxableAmount=annualSalary-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf();
		
		System.out.println("taxableAmount is"+taxableAmount);
		
		if(annualSalary<=250000)
			return grossSalary-associate.getSalary().getEpf();
		else if(annualSalary>=250000&&taxableAmount<=500000) {
			taxableAmount=250000;
			int monthlyTax=(taxableAmount/10)/12;
			return grossSalary-monthlyTax-associate.getSalary().getEpf();
		}
		
	
		else if(annualSalary>=500000&&taxableAmount<=1000000) {
			taxableAmount=500000;
			int monthlyTax=(taxableAmount/5)/25000;
			return grossSalary-monthlyTax-associate.getSalary().getEpf();		
		}
		
		else if(annualSalary>1000000) {
			taxableAmount=1000000;
			int monthlyTax=(taxableAmount*30)/100+125000/12;
			return grossSalary-monthlyTax-associate.getSalary().getEpf();		
		
		}
		
		return 0;
	}

@Override
	public Associate getAssociateDetails(int associateId) throws  AssociateDetailsNotFoundException{
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null) throw new AssociateDetailsNotFoundException ("AssociateDetailsNotFound for associateId");
		return associate;
	}

	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDAO.findAll();
	}
}
