package com.cg.session.beans;

public class UserBean {

	private String firstName,lastName,fruitName,bookName,movieName;

	public UserBean() {
		super();
	}

	public UserBean(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public UserBean(String fruitName, String bookName, String movieName) {
		super();
		this.fruitName = fruitName;
		this.bookName = bookName;
		this.movieName = movieName;
	}

	
	
}
