package com.cg.session.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.session.beans.UserBean;

@WebServlet("/SocialInfoServlet")
public class SocialInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public SocialInfoServlet() {
        super();
      
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	PrintWriter out=response.getWriter();
	String firstName=request.getParameter("firstName");
	String lastName=request.getParameter("lastName");
	String movieName=request.getParameter("movieName");
	String bookName=request.getParameter("bookName");
	String fruitName=request.getParameter("fruitName");
		
	out.println("<html><body>");
			out.println("First Name" +firstName+"<br>");
			out.println("Last Name" +lastName+"<br>");
			out.println("Movie Name" +movieName+"<br>");
			out.println("Book Name" +bookName+"<br>");
			out.println("fruit Name" +fruitName+"<br>");
			
	     out.println("</html></body>");
	
	
	
	
	
	
	
	
	
			
			
		

}
}