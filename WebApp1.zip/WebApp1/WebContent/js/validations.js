function validateRegistrationform(){
	if(registerForm.firstName.value==" "){
		alert("Enter first name");
		return false
	}
	else if(registerForm.lastName.value==" "){
		alert("Enter last name");
		return false
	}
	else if(registerForm.emailId.value==" "){
		alert("Enter email id ");
		return false
	}
	else if(registerForm.department.value==" "){
		alert("Enter department");
		return false
	}
	else if(registerForm.designation.value==" "){
		alert("Enter designation");
		return false
	}
	else if(registerForm.pancard.value==" "){
		alert("Enter pancard");
		return false
	}
	else if(registerForm.yearlyinvestmentUnder80C.value==" "){
		alert("Enter yearlyinvestmentUnder80C");
		return false
	}
	else if(registerForm.basicSalary.value==" "){
		alert("Enter basicSalary");
		return false
	}
	else if(registerForm.bankName.value==" "){
		alert("Enter bankName");
		return false
	}
	else if(registerForm.accountNo.value==" "){
		alert("Enter accountNo");
		return false
	}
	else if(registerForm.ifscCode.value==" "){
		alert("Enter ifscCode");
		return false
	}
	
	}
	
	
	
	