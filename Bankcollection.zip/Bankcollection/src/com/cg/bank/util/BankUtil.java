package com.cg.bank.util;

import java.util.HashMap;

import com.cg.bank.customer.Customer;

public class BankUtil {
	public static int CUSTOMER_ID_COUNTER=200;
	public static HashMap<Integer, Customer>customers =new HashMap<>();
	
	public static int getCUSTOMER_ID_COUNTER() {
		return ++CUSTOMER_ID_COUNTER;
	}
	
}
