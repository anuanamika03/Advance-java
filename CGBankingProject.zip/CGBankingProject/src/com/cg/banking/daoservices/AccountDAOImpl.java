package com.cg.banking.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.banking.beans.Account;

public class AccountDAOImpl implements AccountDAO{
	private EntityManagerFactory entityManagerfactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Account save(Account account) {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.clear();
		return account;
		
	}

	@Override
	public boolean update(Account account) {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.clear();
		return true;
		
	}

	@Override
	public Account findOne(long accountNo) {
		return entityManagerfactory.createEntityManager().find(Account.class, accountNo);
		
	}

	@Override
	public List<Account> findAll() {
		EntityManager entityManager=entityManagerfactory.createEntityManager();
		Query query=	entityManager.createQuery("from Associate a");// used to create multiple objects
			return query.getResultList();
		}
		

	
}
